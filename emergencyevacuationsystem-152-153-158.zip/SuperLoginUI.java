import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class SuperLoginUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel statusLabel;
    private Map<String, String[]> users = new HashMap<>();
    private String loggedInUser;
    private final int nodes = 100; 
    

    private int[][] housePositions = new int[nodes][2];
    private int[][] graph = new int[nodes][nodes];

    public SuperLoginUI() {
        loadUsers();
        setTitle("Emergency evacuation system");
        setSize(500, 700);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(30, 30, 30));


        JLabel title = new JLabel("Emergency Evacuation System", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 25));
        title.setForeground(Color.WHITE);
        title.setBounds(50, 190, 400, 40);
        add(title);

        usernameField = new JTextField();
        usernameField.setBounds(150, 250, 200, 30);
        usernameField.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        usernameField.setBackground(new Color(70, 70, 70));
        usernameField.setForeground(Color.WHITE);
        add(usernameField);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 300, 200, 30);
        passwordField.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        passwordField.setBackground(new Color(70, 70, 70));
        passwordField.setForeground(Color.WHITE);
        add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(150, 350, 200, 40);
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(0, 120, 215));
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createEmptyBorder());
        loginButton.addActionListener(e -> login());
        add(loginButton);

        JLabel forgotLabel = new JLabel("Forgot Password?", SwingConstants.CENTER);
        forgotLabel.setBounds(150, 400, 200, 30);
        forgotLabel.setForeground(Color.WHITE);
        forgotLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        forgotLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                forgotPassword();
            }
        });
        add(forgotLabel);

        JLabel signupLabel = new JLabel("Create a new account", SwingConstants.CENTER);
        signupLabel.setBounds(150, 450, 200, 30);
        signupLabel.setForeground(Color.WHITE);
        signupLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        signupLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                signup();
            }
        });
        add(signupLabel);

        statusLabel = new JLabel("", SwingConstants.CENTER);
        statusLabel.setBounds(50, 500, 400, 30);
        statusLabel.setForeground(Color.RED);
        add(statusLabel);

        setLocationRelativeTo(null);
        setVisible(true);
        initializeHousesAndGraph();
    }

    private void initializeHousesAndGraph() {
        Random rand = new Random();
        int minDistance = 30; 

        for (int i = 0; i < nodes; i++) {
            int x, y;
            boolean positionValid;
            do {
                x = rand.nextInt(500) + 25;
                y = rand.nextInt(500) + 25;
                positionValid = true;
            
                for (int j = 0; j < i; j++) {
                    int dx = x - housePositions[j][0];
                    int dy = y - housePositions[j][1];
                    if (Math.sqrt(dx * dx + dy * dy) < minDistance) {
                        positionValid = false;
                        break;
                    }
                }
            } while (!positionValid);

            housePositions[i][0] = x;
            housePositions[i][1] = y;
        }

        for (int i = 0; i < nodes; i++) {
            Arrays.fill(graph[i], 0);
            int connections = 5; 

            for (int j = 0; j < connections; j++) {
                int neighbor;
                do {
                    neighbor = rand.nextInt(nodes);
                } while (neighbor == i || graph[i][neighbor] != 0);

                int distance = (int) Math.sqrt(
                        Math.pow(housePositions[i][0] - housePositions[neighbor][0], 2) +
                        Math.pow(housePositions[i][1] - housePositions[neighbor][1], 2)
                );

                graph[i][neighbor] = distance;
                graph[neighbor][i] = distance; 
            }
        }
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (users.containsKey(username)) {
            String[] data = users.get(username);
            if (data[0].equals(password)) {
                statusLabel.setText("Login successful!");
                statusLabel.setForeground(Color.GREEN);
                loggedInUser = username;
                showEmergencyPage();
            } else {
                statusLabel.setText("Incorrect password.");
            }
        } else {
            statusLabel.setText("Username not found.");
        }
    }

    private void forgotPassword() {
        String username = JOptionPane.showInputDialog(this, "Enter your username:");
        if (users.containsKey(username)) {
            String question = users.get(username)[1];
            String answer = JOptionPane.showInputDialog(this, question);
            if (users.get(username)[2].equals(answer)) {
                String newPassword = JOptionPane.showInputDialog(this, "Enter your new password:");
                users.get(username)[0] = newPassword;
                saveUsers();
                JOptionPane.showMessageDialog(this, "Password reset successful!");
            } else {
                JOptionPane.showMessageDialog(this, "Incorrect answer to the security question.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Username not found.");
        }
    }

    private void signup() {
        String username = JOptionPane.showInputDialog(this, "Enter a username:");
        if (!users.containsKey(username)) {
            String password = JOptionPane.showInputDialog(this, "Enter a password:");
            String question = JOptionPane.showInputDialog(this, "Enter a security question:");
            String answer = JOptionPane.showInputDialog(this, "Enter the answer to the security question:");

            users.put(username, new String[]{password, question, answer});
            saveUsers();
            JOptionPane.showMessageDialog(this, "Signup successful!");
        } else {
            JOptionPane.showMessageDialog(this, "Username already exists.");
        }
    }

    private void loadUsers() {
        File file = new File("users.txt");
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(":");
                    users.put(parts[0], new String[]{parts[1], parts[2], parts[3]});
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt"))) {
            for (Map.Entry<String, String[]> entry : users.entrySet()) {
                String[] data = entry.getValue();
                writer.write(entry.getKey() + ":" + data[0] + ":" + data[1] + ":" + data[2]);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showEmergencyPage() {
        getContentPane().removeAll();
        repaint();

        setLayout(null);
        JLabel emergencyLabel = new JLabel("Emergency Path Finder", SwingConstants.CENTER);
        emergencyLabel.setFont(new Font("Serif", Font.BOLD, 28));
        emergencyLabel.setForeground(Color.BLACK);
        emergencyLabel.setBounds(50, 50, 400, 50);
        add(emergencyLabel);

        JButton emergencyButton = new JButton("Find Shortest Path to Home");
        emergencyButton.setBounds(100, 200, 300, 40);
        emergencyButton.setForeground(Color.WHITE);
        emergencyButton.setBackground(new Color(220, 0, 78));
        emergencyButton.setFocusPainted(false);
        emergencyButton.setBorder(BorderFactory.createEmptyBorder());
        emergencyButton.addActionListener(e -> promptForHouseNumber());
        add(emergencyButton);

        setVisible(true);
    }

    private void promptForHouseNumber() {
        String houseNumberStr = JOptionPane.showInputDialog(this, "Enter your house number (1-100):");
        try {
            int houseNumber = Integer.parseInt(houseNumberStr);
            if (houseNumber < 1 || houseNumber > 100) {
                JOptionPane.showMessageDialog(this, "Invalid house number! Please enter a number between 1 and 100.");
            } else {
                findShortestPath(houseNumber - 1);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number.");
        }
    }

    private int[] dijkstra(int src, int dest) {
        int[] dist = new int[nodes];
        boolean[] visited = new boolean[nodes];
        int[] prev = new int[nodes];
        Arrays.fill(dist, Integer.MAX_VALUE);
        Arrays.fill(prev, -1);
        dist[src] = 0;

        for (int i = 0; i < nodes - 1; i++) {
            int u = minDistance(dist, visited);
            if (u == -1) break;
            visited[u] = true;

            for (int v = 0; v < nodes; v++) {
                if (!visited[v] && graph[u][v] != 0 && dist[u] != Integer.MAX_VALUE && dist[u] + graph[u][v] < dist[v]) {
                    dist[v] = dist[u] + graph[u][v];
                    prev[v] = u;
                }
            }
        }

        Stack<Integer> path = new Stack<>();
        for (int at = dest; at != -1; at = prev[at]) {
            path.push(at);
        }

        int[] resultPath = new int[path.size()];
        for (int i = 0; i < resultPath.length; i++) {
            resultPath[i] = path.pop();
        }
        return resultPath;
    }

    private int minDistance(int[] dist, boolean[] visited) {
        int min = Integer.MAX_VALUE, minIndex = -1;
        for (int i = 0; i < nodes; i++) {
            if (!visited[i] && dist[i] < min) {
                min = dist[i];
                minIndex = i;
            }
        }
        return minIndex;
    }

    private void findShortestPath(int destination) {
        int[] shortestPath = dijkstra(0, destination);
        JFrame animationFrame = new JFrame("Path Animation");
        animationFrame.setSize(600, 600);
        animationFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mapPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, getWidth(), getHeight());

                for (int i = 0; i < nodes; i++) {
                    int x = housePositions[i][0];
                    int y = housePositions[i][1];

                    if (i == destination) {
                        g.setColor(Color.RED);  
                    } else {
                        g.setColor(Color.DARK_GRAY);
                    }

                    g.fillRect(x - 5, y - 10, 10, 10);

                    int[] xPoints = {x - 5, x, x + 5};
                    int[] yPoints = {y - 10, y - 20, y - 10};
                    g.fillPolygon(xPoints, yPoints, 3);

                    g.setColor(Color.BLACK);
                    g.drawString(String.valueOf(i + 1), x + 6, y - 5);
                }

                g.setColor(Color.BLUE);
                int distance = 0;
                for (int i = 0; i < shortestPath.length - 1; i++) {
                    int x1 = housePositions[shortestPath[i]][0];
                    int y1 = housePositions[shortestPath[i]][1];
                    int x2 = housePositions[shortestPath[i + 1]][0];
                    int y2 = housePositions[shortestPath[i + 1]][1];
                    g.drawLine(x1, y1, x2, y2);

                    distance += graph[shortestPath[i]][shortestPath[i + 1]];
                }

                double speed = 50.0;
                double time = distance / speed;
                g.setColor(Color.BLACK);
                g.drawString("Distance: " + distance + " units", 20, 20);
                g.drawString("Estimated Time: " + String.format("%.2f", time) + " units", 20, 40);
            }
        };

        animationFrame.add(mapPanel);
        animationFrame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SuperLoginUI::new);
    }
}